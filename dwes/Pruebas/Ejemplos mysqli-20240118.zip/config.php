<?php
//Conexión a BBDD
const BBDD_HOST = "localhost";
const BBDD_NAME = "bbddejemplo";
const BBDD_USER = "loginejemplo";
const BBDD_PASSWORD = "l.mPnkPRbiO9GIXe";


